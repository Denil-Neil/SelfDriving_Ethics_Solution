
// for Json::value
#include <json/json.h>
#include <json/reader.h>
#include <json/writer.h>
#include <json/value.h>
#include <string>

// for JsonRPCCPP
#include <iostream>
#include "hw5server.h"
#include <jsonrpccpp/server/connectors/httpserver.h>
// #include "hw5client.h"
#include <jsonrpccpp/client/connectors/httpclient.h>
#include <stdio.h>

// ecs36b
#include "Person.h"
#include "Item.h"
#include <time.h>

using namespace jsonrpc;
using namespace std; 

// std::map (key, value pairs)
/* std::map<std::string, Item *> Item;
std::map<std::string, Person *> Person_Map; */

// my location
//GPS_DD process_here;

class Myhw5Server : public hw5Server
{
public:
  Myhw5Server(AbstractServerConnector &connector, serverVersion_t type);

  virtual Json::Value move(const std::string& action,
			   const std::string& class_id,
			   const Json::Value& json_object,
			   const Json::Value& location,
			   const std::string& object_id);

  virtual Json::Value move2(const std::string& action,
			   const std::string& class_id,
			   const Json::Value& json_object,
			   const Json::Value& location,
			   const std::string& object_id);
         
  virtual Json::Value done();  

  std::map<std::string, Item *> Item_Map;
  std::map<std::string, Person *> Person_Map;
  bool is_done = false;
};

Myhw5Server::Myhw5Server(AbstractServerConnector &connector, serverVersion_t type)
  : hw5Server(connector, type)
{
  std::cout << "Myhw5Server Object created" << std::endl;
}

// member functions
//can most likely just make a move2 function for items

Json::Value Myhw5Server::move
(const std::string& action, const std::string& class_id,
 const Json::Value& json_object, const Json::Value& location,
 const std::string& object_id)
{
  Json::Value result;
    Person * lv_person_ptr;
      if (Person_Map.find(object_id) != Person_Map.end()) {
      lv_person_ptr = Person_Map[object_id];
    } else {
      lv_person_ptr = new Person {};
      Person_Map[object_id] = lv_person_ptr;
    }
  lv_person_ptr->JSON2Object(json_object);
  result = json_object;
std::cout << "result: \n" << result.toStyledString() << std::endl;
return result;
}

Json::Value Myhw5Server::move2
(const std::string& action, const std::string& class_id,
 const Json::Value& json_object2, const Json::Value& location,
 const std::string& object_id2)
{
  Json::Value result2;
    Item * lv_item_ptr;
      if (Item_Map.find(object_id2) != Item_Map.end()) {
      lv_item_ptr = Item_Map[object_id2];
    } else {
      lv_item_ptr = new Item {};
      Item_Map[object_id2] = lv_item_ptr;
    }
  lv_item_ptr->JSON2Object(json_object2);
  result2 = json_object2;
std::cout << "result: \n" << result2.toStyledString() << std::endl;
return result2;
}

Json::Value Myhw5Server::done()
{
  Json::Value result;
  result["done"] = "Data sent";
  std::cout << "- sending to next Server\n" << result.toStyledString() << std::endl;
  is_done = true;
  return result;
}
