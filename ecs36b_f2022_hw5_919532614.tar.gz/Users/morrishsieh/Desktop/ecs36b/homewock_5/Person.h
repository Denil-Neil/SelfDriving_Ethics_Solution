
#ifndef _PERSON_H_
#define _PERSON_H_

// Person.h

//json stuff
#include <string>
#include <iostream>
#include "CommonFunctions.h"

#include <json/json.h>
#include <json/reader.h>
#include <json/writer.h>
#include <json/value.h>

class Person
{
 private:
 std::string name;
 public:
  Person(std::string Who);
  Person();
  std::string getName();
  bool operator==(Person& aPerson);
  virtual Json::Value dump2JSON();
  virtual bool JSON2Object(Json::Value);
};

#endif  /* _PERSON_H_ */