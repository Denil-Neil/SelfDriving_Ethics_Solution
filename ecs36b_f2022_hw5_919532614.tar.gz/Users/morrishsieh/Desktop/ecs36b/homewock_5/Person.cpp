#include "Person.h"

Person::Person(std::string Who)
{
    this->name = Who;
}

Person::Person()
{
    this->name = "";
}
std::string Person::getName()
{
    return name;
}

Json::Value
Person::dump2JSON
(void)
{
  Json::Value result {};

  if (this->name != "")
    {
      result["Name"] = this->name;
    }

  return result;
}

bool Person::JSON2Object (Json::Value arg_jv)
{

  if ((arg_jv.isNull() == true) ||
      (arg_jv.isObject() != true))
    {
      return false;
    }

  if (((arg_jv["Name"]).isNull() == true) || ((arg_jv["Name"]).isString() != true))
    {
      return false;
    }

  // we allow GPS_DD to be modified (for mobility)
  this->name = (arg_jv["Name"]).asString();
  return true;
}