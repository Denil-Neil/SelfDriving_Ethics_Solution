#ifndef _ITEM_H_
#define _ITEM_H_

#include <string>
#include <iostream>
#include "CommonFunctions.h"

#include <json/json.h>
#include <json/reader.h>
#include <json/writer.h>
#include <json/value.h>

class Item
{
 private:
 std::string item;
 public:
  Item(std::string What);
  Item();
  std::string getItem();
  bool operator==(Item& aItem);
  virtual Json::Value dump2JSON();
  virtual bool JSON2Object(Json::Value);
};


#endif /* _ITEM_H_ */
