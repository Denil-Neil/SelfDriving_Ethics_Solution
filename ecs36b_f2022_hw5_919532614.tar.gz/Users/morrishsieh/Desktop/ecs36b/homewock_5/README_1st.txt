To run the program, type make to execute the makefile, then create the three servers:
./grandma
./forest
./village

In respective order. As soon as the three servers are created, the Person and the Thing objects are moved from the bottom one to the top one, which fulfills object mobility.

Students' names in the team:

Mu-Wei Hsieh, 919532614
Greg Chang, 919809198
Patrick Nguyen, 919509980
Denil
