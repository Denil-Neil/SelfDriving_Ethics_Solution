#include "Item.h"

Item::Item(std::string What)
{
    this->item = What;
}

Item::Item()
{
    this->item = "";
}

std::string Item::getItem()
{
    return this->item;
}


Json::Value
Item::dump2JSON
(void)
{
  Json::Value result = {};
  if (this->item != "")
    {
      result["Item"] = this->item;
    }

  return result;
}

bool Item::JSON2Object (Json::Value arg_jv)
{

  if ((arg_jv.isNull() == true) ||
      (arg_jv.isObject() != true))
    {
      return false;
    }

   if (((arg_jv["Item"]).isNull() == true) ||
      ((arg_jv["Item"]).isString() != true))
    {
      return false;
    }
    
  this->item = (arg_jv["Item"]).asString();

  return true;
}
